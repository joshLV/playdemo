package models.resale;

public enum ResalerStatus {
	PENDING,   //处理中，待审核
	APPROVED,//审核通过
	UNAPPROVED,//审核未通过
    NORMAL
}
