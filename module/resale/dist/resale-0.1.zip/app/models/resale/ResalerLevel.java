package models.resale;


public enum ResalerLevel {
	NORMAL
//	VIP1,
//	VIP2,
//	VIP3
}
