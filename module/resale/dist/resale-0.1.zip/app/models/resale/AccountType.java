package models.resale;

public enum AccountType {
	CONSUMER,   //个人
	COMPANY//公司
}
