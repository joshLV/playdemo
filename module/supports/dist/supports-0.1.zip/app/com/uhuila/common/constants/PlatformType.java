package com.uhuila.common.constants;

/**
 * 平台类型.
 * <p/>
 * User: sujie
 * Date: 4/23/12
 * Time: 10:44 AM
 */
public enum PlatformType {
    RESALE, UHUILA, SUPPLIER
}
