package util.extension;

/**
 * User: tanglq
 * Date: 13-3-4
 * Time: 下午4:34
 */
public interface ExtensionContext {
}
