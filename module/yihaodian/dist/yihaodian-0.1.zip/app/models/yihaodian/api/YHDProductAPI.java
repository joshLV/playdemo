package models.yihaodian.api;

/**
 * @author likang
 *         Date: 12-10-26
 */
public class YHDProductAPI {
}
