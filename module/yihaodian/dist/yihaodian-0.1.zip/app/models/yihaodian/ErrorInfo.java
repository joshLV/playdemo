package models.yihaodian;

/**
 * @author likang
 *         Date: 12-8-30
 */
public class ErrorInfo {
    public String errorCode;
    public String errorDes;
    public String pkInfo;
}
