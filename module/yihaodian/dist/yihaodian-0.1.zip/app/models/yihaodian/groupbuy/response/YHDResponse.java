package models.yihaodian.groupbuy.response;

/**
 * @author likang
 *         Date: 12-9-19
 */
public class YHDResponse {
    public Object response;
    public YHDResponse(){
        this.response = null;
    }

    public YHDResponse(Object o){
        this.response = o;
    }
}
