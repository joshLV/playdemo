package models.yihaodian.groupbuy.response;

/**
 * @author likang
 *         Date: 12-9-13
 */
public class VoucherInfo {
    public String issueTime;
    public String voucherCode;
    public int voucherCount;
    public String voucherEndTime;
    public String voucherStartTime;

    public VoucherInfo(){}
}
