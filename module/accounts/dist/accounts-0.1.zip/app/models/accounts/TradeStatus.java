package models.accounts;

/**
 * @author likang
 */
public enum TradeStatus {
    UNPAID,     //未支付
    SUCCESS,    //成功
    FAILED,     //失败
}
