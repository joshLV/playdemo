package models.accounts;

/**
 * TODO.
 * <p/>
 * User: sujie
 * Date: 11/13/12
 * Time: 5:01 PM
 */
public enum SettlementStatus {
    CLEARED,
    UNCLEARED
}
