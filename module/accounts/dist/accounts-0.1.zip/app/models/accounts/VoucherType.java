package models.accounts;

/**
 * <p/>
 * User: yanjy
 * Date: 12-12-19
 * Time: 上午11:15
 */
public enum VoucherType {
    EXCHANGE,//消费者兑换
    OPERATE//运营生成
}
