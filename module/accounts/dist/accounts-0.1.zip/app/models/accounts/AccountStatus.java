package models.accounts;

/**
 * @author likang
 */
public enum AccountStatus {
    NORMAL,
    FREEZE,
    CANCEL
}
