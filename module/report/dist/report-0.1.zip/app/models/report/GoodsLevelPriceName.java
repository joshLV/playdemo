package models.report;

/**
 * 各种价格名称.
 * <p/>
 * User: sujie
 * Date: 5/31/12
 * Time: 10:53 AM
 */
public enum GoodsLevelPriceName{
    NORMAL,
    VIP1,
    VIP2,
    VIP3,
    WEBSITE
}
