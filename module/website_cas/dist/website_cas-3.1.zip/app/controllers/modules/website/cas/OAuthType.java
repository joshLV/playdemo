package controllers.modules.website.cas;

/**
 * OAuth类型.
 */
public enum OAuthType {
    SINA
}
