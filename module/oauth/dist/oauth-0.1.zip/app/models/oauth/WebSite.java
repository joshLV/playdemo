package models.oauth;

/**
 * @author  likang
 * Date: 12-5-4
 */
public enum WebSite {
    SINA_WEIBO,
    TENCENT_WEIBO,
    RENREN,
    TAOBAO
}
