package models.consumer;

import com.uhuila.common.util.DateUtil;
import org.apache.commons.lang.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class UserCondition {
    public Date createdAtBegin;
    public Date createdAtEnd;

    public String mobile;
    public String loginName;
    public UserStatus status;
    public String interval = "0";

    public String pointNumber;
    public Map<String, Object> paramsMap = new HashMap<>();

    public String getCondition(User user) {

        StringBuilder sql = new StringBuilder("1=1");
        if (user != null) {
            sql.append(" and u.user = :user");
            paramsMap.put("user", user);
        }

        if (createdAtBegin != null) {
            sql.append(" and u.createdAt >= :createdAtBegin");
            paramsMap.put("createdAtBegin", createdAtBegin);
        }
        if (createdAtEnd != null) {
            sql.append(" and u.createdAt <= :createdAtEnd");
            paramsMap.put("createdAtEnd", DateUtil.getEndOfDay(createdAtEnd));
        }

        if (StringUtils.isNotBlank(pointNumber)) {
            sql.append(" and u.pointNumber = :pointNumber");
            paramsMap.put("pointNumber", pointNumber);
        }

        return sql.toString();
    }

    public String getFilter() {
        StringBuilder sql = new StringBuilder("1=1");
        if (createdAtBegin != null) {
            sql.append(" and u.createdAt >= :createdAtBegin");
            paramsMap.put("createdAtBegin", createdAtBegin);
        }
        if (createdAtEnd != null) {
            sql.append(" and u.createdAt <= :createdAtEnd");
            paramsMap.put("createdAtEnd", DateUtil.getEndOfDay(createdAtEnd));
        }

        if (StringUtils.isNotBlank(loginName)) {
            sql.append(" and u.loginName like :loginName");
            paramsMap.put("loginName", "%" + loginName.trim() + "%");
        }
        if (StringUtils.isNotBlank(mobile)) {
            sql.append(" and u.mobile = :mobile");
            paramsMap.put("mobile", mobile);
        }
        if (status != null) {
            sql.append(" and u.status = :status");
            paramsMap.put("status", status);
        }
        return sql.toString();
    }

    public Map<String, Object> getParamMap() {
        return paramsMap;
    }
}
