package models.consumer;

/**
 * 第三方登录应用名称.
 * <p/>
 * User: sujie
 * Date: 9/10/12
 * Time: 4:28 PM
 */
public enum OpenIdSource {
    SinaWeibo,
    QQ,
    RenRen,
    Kaixin
}
