package models.consumer;

public enum UserStatus {
	NORMAL,
	FREEZE
}
