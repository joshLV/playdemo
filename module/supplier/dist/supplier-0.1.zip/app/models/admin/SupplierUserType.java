package models.admin;

/**
 * @author likang
 *         Date: 12-8-3
 */
public enum SupplierUserType {
    ANDROID,
    HUMAN
}
