package models.cms;

/**
 * <p/>
 * User: yanjy
 * Date: 12-7-17
 * Time: 下午4:17
 */
public enum LinkStatus {
    FORBID,//禁止
    OPEN,//开放
    SAVE,//保存但不开放
    BLACK//黑名单
}
