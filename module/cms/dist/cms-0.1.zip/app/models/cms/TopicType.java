package models.cms;

/**
 * 公告通知类型.
 * <p/>
 * User: sujie
 * Date: 4/23/12
 * Time: 11:08 AM
 */
public enum TopicType {
    NOTICE, NEWS, TOPIC, WEB_CATEGORY1, WEB_CATEGORY2, WEB_CATEGORY3, WEB_CATEGORY4, WEB_CATEGORY5
}
