package models.cms;

/**
 * 公告通知类型.
 * <p/>
 * User: sujie
 * Date: 4/23/12
 * Time: 11:08 AM
 */
public enum TopicType {
    NOTICE,NEWS,COUPON
}
