package models.cms;

/**
 * <p/>
 * User: yanjy
 * Date: 12-6-11
 * Time: 下午2:24
 */
public enum VoteType {
    QUIZ,//有奖问答
    INQUIRY//用户调查
}
