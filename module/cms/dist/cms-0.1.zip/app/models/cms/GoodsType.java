package models.cms;

/**
 * Created with IntelliJ IDEA.
 * User: hejun
 * Date: 12-8-6
 * Time: 下午5:43
 * To change this template use File | Settings | File Templates.
 */
public enum GoodsType {
    NORMALGOODS,    //普通商品
    POINTGOODS,    //积分商品
}
