package models.cms;

/**
 * User: hejun
 * Date: 12-8-6
 * Time: 下午5:43
 */
public enum GoodsType {
    NORMALGOODS,    //普通商品
    POINTGOODS,    //积分商品
}
