package models.cms;

public enum BlockType {
    WEBSITE_SLIDE, DAILY_SPECIAL
}
