package models.sms;

/**
 * @author likang
 *         Date: 12-8-16
 */
public enum MobileBindType {
    BIND_CONSUME
}
