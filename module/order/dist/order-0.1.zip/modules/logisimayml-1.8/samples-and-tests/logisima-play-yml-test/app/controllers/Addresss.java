package controllers;


public class Addresss extends CRUD {

}
