package controllers;

public class Posts extends CRUD {

}
