package models.order;

/**
 * @author likang
 * Date: 12-5-10
 */
public enum OrderType {
    CONSUME,    //消费订单
    CHARGE      //充值订单
}
