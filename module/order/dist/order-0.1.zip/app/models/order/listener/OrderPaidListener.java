package models.order.listener;

public interface OrderPaidListener {

}
