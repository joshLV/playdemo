package models.order.listener;

public interface OrderRefundListener {

}
