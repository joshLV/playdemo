package models.order;

/**
 * @author likang
 *         Date: 12-9-18
 */
public enum OuterOrderPartner {
    DD,     //当当
    YHD,    //一号店
    JD      //京东
}
