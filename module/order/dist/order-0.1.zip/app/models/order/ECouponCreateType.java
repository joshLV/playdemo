package models.order;

/**
 * @author likang
 *         Date: 12-9-11
 */
public enum ECouponCreateType {
    GENERATE,   //自动生成
    IMPORT      //导入
}
