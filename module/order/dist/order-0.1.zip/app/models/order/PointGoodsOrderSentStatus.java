package models.order;

/**
 * Created with IntelliJ IDEA.
 * User: clara
 * Date: 12-8-13
 * Time: 下午2:47
 * To change this template use File | Settings | File Templates.
 */

public enum PointGoodsOrderSentStatus {
    SENT,      //已发货
    UNSENT,    //未发货
    UNAPPROVED  //审核未通过

}
