package models.order;

/**
 * User: pwg
 * Date: 12-3-5
 */
public enum ECouponStatus {
    UNCONSUMED, // 未消费
    CONSUMED,   //已消费
    REFUND     //已退款
}
