package models.order;

/**
 * Created by IntelliJ IDEA.
 * User: pwg
 * Date: 12-3-5
 * Time: 下午4:52
 * To change this template use File | Settings | File Templates.
 */
public enum ECouponStatus {
    DEALING,//处理中
    CONSUMED,//已消费
    UNCONSUMED,// 未消费
    REFUND,//已退款
    EXPIRED,//已过期,
}
