package models.order;

/**
 * TODO.
 * <p/>
 * User: sujie
 * Date: 2/20/12
 * Time: 5:50 PM
 */
public class NotEnoughInventoryException extends Exception{
}
