package models.order;

public enum OrderStatus{
    UNPAID,
    PAID,
    CANCELED,
    SENT,
    RETURNED,
    RECEIPT
}
