package models.order;

/**
 * @author likang
 *         Date: 12-10-17
 */
public enum ECouponPartner {
    JD,     // 京东
    DD,     // 当当
    YHD,    // 一号店
    WB,     // 58
    WUBA,
    TB,     // 淘宝
}
