package models.order;

/**
 * <p/>
 * User: yanjy
 * Date: 12-9-3
 * Time: 上午10:28
 */
public enum RebateStatus {
    ALREADY_REBATE,//已返利
    UN_CONSUMED, //下单未消费
    PART_REBATE//部分已返利

}
