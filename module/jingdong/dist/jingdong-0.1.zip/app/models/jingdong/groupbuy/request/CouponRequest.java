package models.jingdong.groupbuy.request;

import java.io.Serializable;

/**
 * @author likang
 *         Date: 12-10-7
 */
public class CouponRequest implements Serializable {
    private static final long serialVersionUID = 7023262063910330654L;

    public String couponId;
    public String couponPwd;
}
