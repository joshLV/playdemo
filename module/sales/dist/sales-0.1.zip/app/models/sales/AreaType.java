package models.sales;

/**
 * 区域类型.
 * <p/>
 * User: sujie
 * Date: 2/28/12
 * Time: 11:59 AM
 */
public enum AreaType {
    CITY, DISTRICT, AREA,
}
