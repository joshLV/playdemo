package models.sales;

/**
 * @author likang
 *         Date: 12-9-8
 */
public enum ImportedCouponStatus {
    UNUSED,
    USED
}
