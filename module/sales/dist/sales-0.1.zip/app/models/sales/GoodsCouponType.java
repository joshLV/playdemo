package models.sales;

/**
 * @author likang
 *         Date: 12-9-8
 */
public enum GoodsCouponType {
    GENERATE,   //自动生成的券
    IMPORT      //导入的券
}
