package models.sales;

import play.db.jpa.Model;

/**
 * Created with IntelliJ IDEA.
 * User: wangjia
 * Date: 12-9-24
 * Time: 下午12:41
 * To change this template use File | Settings | File Templates.
 */
public class ConsultResultCondition  extends Model {
}
