package models.sales;

/**
 * TODO.
 * <p/>
 * User: yanjy
 * Date: 12-7-4
 * Time: 上午10:59
 */
public enum GoodsStatisticsType {
    VISITOR, BUY, ADD_CART, LIKE
}
