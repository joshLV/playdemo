package models.sales;

/**
 * 商品发布平台.
 * <p/>
 * User: sujie
 * Date: 5/2/12
 * Time: 10:48 AM
 */
public enum GoodsPublishedPlatformType {
    TAOBAO, DANGDANG, YIHAODIAN
}
