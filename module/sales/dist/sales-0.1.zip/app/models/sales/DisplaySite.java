package models.sales;

/**
 * <p/>
 * User: yanjy
 * Date: 12-10-22
 * Time: 下午5:40
 */
public enum DisplaySite {
    WWW_DISPLAY,//作为首页展示
    WWW_MAIN,//作为主图
    WWW_BOTH//即可为主图,也可以首页展示

}
