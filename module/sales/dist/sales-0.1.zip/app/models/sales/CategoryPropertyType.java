package models.sales;

/**
 * 分类属性的类型.
 * <p/>
 * User: sujie
 * Date: 2/28/12
 * Time: 4:27 PM
 */
public enum CategoryPropertyType {
    TEXT, IMAGE
}
