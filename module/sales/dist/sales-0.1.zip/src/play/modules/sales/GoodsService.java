package play.modules.sales;

/**
 * 商品服务.
 *
 * User: sujie
 * Date: 2/9/12
 * Time: 11:07 AM
 */
public interface GoodsService {
    public void addGoods(Object goods);
}
