package models.dangdang;

/**
 * 当当券对象.
 * <p/>
 * User: sujie
 * Date: 9/15/12
 * Time: 7:15 PM
 */
public class DDECoupon {
    public Long orderId;
    public Long ddgid;
    public Long spgid;
    public String userCode;
    public String receiveMobile;
    public String consumeId;

}
